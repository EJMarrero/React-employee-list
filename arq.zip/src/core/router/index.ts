export * from './router.component';
export { routes } from './routes';
